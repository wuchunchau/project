@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')
<h2> Welcome to Dish Digger!! </h2>

<br>
<p>--Available Dishes--</p>
<ul>
    @foreach ($dishes as $dish)
        <a href="dish/{{$dish->id}}"><li>{{$dish->name}}</li>
    @endforeach
</ul>



    @if(Auth::check())
        @if (Auth::user()->usertype == 'restaurant')
            <p><strong><a href='{{url("dish/create")}}'>---Add New Dish---</strong></a></p>
            <p><strong><a href='{{url("purchase")}}'>---See list of orders of your restaurant!---</strong></a></p>



            
        @endif
    @endif
<br>
    {{$dishes->links()}}
<br>
    
    




<p><strong><a href="{{url ("restaurant")}}">---See all restaurant's dish!---</a></p></strong><br>

@endsection