@extends('layouts.app')

@section('title')

    Dishes
@endsection
@section('content')
<link rel="stylesheet" type="text/css" href="{{asset('css/wp.css')}}">


    <h1>{{$dish->name}}</h1>

    @if($dish->image)
        <img src="{{url($dish->image)}}" alt="dish image" style="width:300px;height:300px;">
    @else
        <p>There are no photo avaiable for this dish!</P>
    @endif

    <p>Price: {{$dish->price}}</p>

    @if(Auth::check())
        @if (Auth::user()->usertype == 'consumer')

            <h4><a href='{{url("purchase/create")}}'>Purchase dish</a></h4>

        @endif
    @endif
    <br>
    <br>

    <h3><a href="{{url ("restaurant/$restaurant->id")}}">Find more dishes from {{$restaurant->name}}!!</a></h3>
 
    @if(Auth::check())
        @if (Auth::user()->name == $restaurant->name)
        <h4><a href='{{url("dish/$dish->id/edit")}}'>update dish</a></h4>
        
        <h5>
            <form method="POST" action='{{url("dish/$dish->id")}}'>
                {{csrf_field()}}
                {{ method_field('DELETE')}}
                <input type="submit" value="Delete">
            </form>
        </h5>   
        @endif
    
    @endif



    

@endsection