@extends('layouts.app')
@section('title')
    Dishes
@endsection


@section('content')




  <form method="POST" action='{{url("dish")}}'enctype="multipart/form-data">
    {{csrf_field()}}
    @if (count($errors->get('name')) > 0)
      <p><label>Name </label>
      <input type="text" name="name" value= "{{ old('name')}}">
        <div class="alert">

            {{$errors->first('name')}}

        </div>
    </p>
    @else

      <p><label>Name </label>
      <input type="text" name="name" value= "{{ old('name')}}" >

        
   </p>
    @endif


    @if (count($errors->get('price')) > 0)
      <p><label>Price </label>
      <input type="text" name="price" value= "{{ old('price')}}">
        <div class="alert">
  
            {{$errors->first('price')}}
          
        </div>
    @else
      <p><label>Price </label>
      <input type="text" name="price" value= "{{ old('price')}}">
      </p>
    @endif

    @if (count($errors->get('image')) > 0)
      <p><input type="file" name="image"> </p>
      <p>Upload image for your dish!!</p>
      <div class="alert">
  
       {{$errors->first('image')}}

      </div>
    @else
      <p><input type="file" name="image"> </p>
      <p>Upload image for your dish!!</p>
    @endif

      <input type="hidden" name="user" value= "{{Auth::id()}}">

      <input type="submit" value="Create"> 
  </form>
@endsection