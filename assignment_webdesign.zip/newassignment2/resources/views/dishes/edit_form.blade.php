@extends('layouts.app')

@section('title')
  Dishes
@endsection

@section('content')



<form method="post" action=' {{url("dish/$dish->id")}}'>
  {{csrf_field()}}
  {{method_field('PUT')}}

    @if (count($errors->get('name')) > 0)
    <p><label>Name </label>
    <input type="text" name="name" value= "{{ old('$dish->name') }}">
      <div class="alert">
    
          {{$errors->first('name')}}
        
      </div>
    @else     
    <p><label>Name </label>
    <input type="text" name="name" value= "{{ $dish->name }}"readonly>
    @endif
   </p>


  <p>

    @if (count($errors->get('price')) > 0)
    <label>Price</label>
    <input type="text" name="price" value= "{{ old('$dish->price') }}"> 
      <div class="alert">
        
          {{$errors->first('price')}}
        
      </div>
    @else
    <label>Price</label>
    <input type="text" name="price" value= "{{ $dish->price }}"> 
    @endif
  </p>
  




  <input type="submit" value="Update">
</form>
@endsection

