@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')


    <ul>
    @foreach ($restaurants as $restaurant)
        <li><a href="{{url ("restaurant/$restaurant->id")}}">{{$restaurant->name}}</a></li>
    @endforeach

    </ul>

    
    
@endsection