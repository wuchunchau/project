@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')

    <ul>
        @foreach($dishes as $dish)
        <li><a href='{{url ("dish/$dish->id")}}'>{{$dish->name}}</a></li>

        @endforeach
    </ul>

    <br>
        {{$dishes->links()}}
    <br>



@endsection