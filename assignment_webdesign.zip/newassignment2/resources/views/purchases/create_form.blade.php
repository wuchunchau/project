@extends('layouts.app')
@section('title')
    Purchase
@endsection


@section('content')




  <form method="POST" action='{{url("purchase")}}'>
    {{csrf_field()}}
    You are ordering {{$dish->name}}

    <br>
    
      <input name = "quantity" type="number" min="1" max="100">


      <input type="hidden" name="user_id" value="{{Auth::id()}}">

      <input type="hidden" name="user_name" value="{{Auth::user()->name}}">


      <input type="hidden" name="dish_id" value= "{{$dish->id}}">

    <br>
    <br>
      <input type="submit" value="Place order"> 
  </form>
@endsection