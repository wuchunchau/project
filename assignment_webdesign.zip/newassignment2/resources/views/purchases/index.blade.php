@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')
<link rel="stylesheet" type="text/css" href="{{asset('css/wp.css')}}">

    <ul>
        @foreach($dishes as $dish)
            @foreach($purchases as $purchase)
                @if($dish->id == $purchase->dish_id)
            
                    <li>====== {{$purchase->user_name}}  ====== {{$dish->name}}  {{$purchase->created_at}} </li>
                @endif
            @endforeach

        @endforeach
    </ul>





@endsection