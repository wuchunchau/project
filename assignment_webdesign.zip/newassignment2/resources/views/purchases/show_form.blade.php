@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')

<link rel="stylesheet" type="text/css" href="{{asset('css/wp.css')}}">
    <h2>Thank you for ordering! Your order were successful!<h2>
    <br>
    <h3>{{$dish->name}}</h3>
    <p>Price per item: <strong>{{$dish->price}}</strong></p>
    <p>Quantity: <strong>{{$purchase->quantity}}</strong></p>
    <br>
    <h3>Consumers details:</h3>
    <p>Consumer name: <strong>{{$user->name}} </strong></p>
    <p>Delivers to:<strong>{{$user->address}} </strong></p>
    




@endsection