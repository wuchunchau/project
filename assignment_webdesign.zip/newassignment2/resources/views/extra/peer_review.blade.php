@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')
<h1>Peer_review</h1>
<!-- relative path -->
<img src= "{{ asset("photos/peer_review.jpg") }}" alt= "peer_review">



@endsection





