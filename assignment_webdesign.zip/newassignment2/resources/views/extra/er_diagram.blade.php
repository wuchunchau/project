@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')
<h1>Er Diagram</h1>
<!-- relative path -->
<img src= "{{ asset("photos/ERD2.JPG") }}" alt="erdiagram">



@endsection


