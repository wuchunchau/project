@extends('layouts.app')
@section('title')
    Dishes
@endsection
@section('content')
<h1>Documentation</h1>
<!-- relative path -->
<img src= "{{ asset("photos/documentation.jpg") }}" alt= "documentation">



@endsection





