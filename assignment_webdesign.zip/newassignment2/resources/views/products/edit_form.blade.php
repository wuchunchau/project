@extends('layouts.app')

@section('title')
  Products
@endsection

@section('content')



<form method="post" action=' {{url("product/$product->id")}}'>
  {{csrf_field()}}
  {{method_field('PUT')}}

    @if (count($errors->get('name')) > 0)
    <p><label>Name </label>
    <input type="text" name="name" value= "{{ old('$product->name') }}">
      <div class="alert">
    
          {{$errors->first('name')}}
        
      </div>
    @else     
    <p><label>Name </label>
    <input type="text" name="name" value= "{{ $product->name }}">
    @endif
   </p>


  <p>

    @if (count($errors->get('price')) > 0)
    <label>Price</label>
    <input type="text" name="price" value= "{{ old('$product->price') }}"> 
      <div class="alert">
        
          {{$errors->first('price')}}
        
      </div>
    @else
    <label>Price</label>
    <input type="text" name="price" value= "{{ $product->price }}"> 
    @endif
  </p>
  
  <select name = "manufacturer">
  @foreach ($manufacturers as $manufacturer)
    @if($manufacturer->id == $product->manufacturer_id)
        <option value="{{$manufacturer->id}}" selected="selected">{{$manufacturer->name}}</option>
    @else
        <option value="{{$manufacturer->id}}">{{$manufacturer->name}}</option>
    @endif 
    @if (count($errors) > 0)
      <div class="alert">
        
          {{$errors->first('manufactuer')}}
        
      </div>
    @endif
  @endforeach
  </select>


  <input type="submit" value="Update">
</form>
@endsection

