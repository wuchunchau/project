<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Product;
use App\Manufacturer;
use App\Dish;
use App\User;
use App\Purchase;


Route::resource('product', 'ProductController');
Route::resource('dish', 'DishController');
Route::resource('restaurant', 'RestaurantController');
Route::resource('purchase', 'PurchaseController');
Route::resource('populardish', 'PopulardishController');


Route::get('/', function () {
    return view('welcome');
});

Route::get('test', function () {

    $products = DB::select('select purchases.dish_id, purchases.quantity from purchases');
    dd($products);
});

Route::get('er_diagram', function () {

    return view('extra/er_diagram');
});

Route::get('documentation', function () {

    return view('extra/documentation');
});

Route::get('peer_review', function () {

    return view('extra/peer_review');
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');
