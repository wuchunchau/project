<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dish extends Model

{
    protected $fillable = ['name', 'price', 'user_id', 'image'];

    function user(){
        return $this->belongsToMany('App\User', 'purchases')->withPivot('quantity');
        // return $this->belongsTo('App\User');
    }
}
