<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Dish;
use App\User;
use App\Purchase;
use Auth;

class PurchaseController extends Controller
{
    function __construct(){
        $this->middleware('auth');

    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // This page shows the sales history of the restaurant
    public function index()
    {
        $user_id = Auth::user()->id;
        $dishes = Dish::where('user_id', '=', $user_id)->get();
        $purchases = Purchase::all();
        
        return view('purchases.index')->with('dishes', $dishes)->with('purchases', $purchases);
         
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

     //This creates a new purchase
    public function create(Request $request)
    {   
        $dish = $request->session()->get('purchasedish');
        
        return view('purchases.create_form')->with('dish', $dish);
    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

      //Store the new purchase
    public function store(Request $request)
    {
        $purchase = new Purchase();
        $purchase->user_name = $request->user_name;
        $purchase->user_id = $request->user_id;
        $purchase->dish_id = $request->dish_id;
        $purchase->quantity = $request->quantity;
        $purchase->save();
        return redirect("purchase/$purchase->id");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

     //This is displayed after the user has successfully made a purchase
    public function show(Request $request, $id)
    {
        $purchase = Purchase::find($id);
        $dish = $request->session()->get('purchasedish');
        $user_id =  Purchase::find($id)->user_id;
        $user = User::find($user_id);

        

        
        return view('purchases.show_form')->with('purchase', $purchase)->with('dish', $dish)->with('user', $user);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
