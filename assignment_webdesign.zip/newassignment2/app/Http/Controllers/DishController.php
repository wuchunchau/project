<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Dish;
use App\User;
class DishController extends Controller

// this middleware requires the user to log in when accessing create and edit page
{
    function __construct(){
        $this->middleware('auth',['only'=>['create', 'edit']]);

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

// This is the index page of DISH, result is paginate into 5 result each page
    public function index()
    {

        $dishes = Dish::paginate(5);

        return view('dishes.index')->with('dishes', $dishes);

    }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    // This is the create form where user create new dish
    public function create()
    {
  
        return view('dishes.create_form')->with('users', User::all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    //  create result are store into the DISH class, validation on values
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:255|unique:dishes',
            'price' => 'required|numeric|min:0.5|max:1000',
            'user' => 'exists:users,id',
            'image' => 'required'
        ]);

        $image_store = request()->file('image')->store('dishes_images', 'public');
        $dish = new Dish();
        $dish->name = $request->name;
        $dish->price = $request->price;
        $dish->user_id = $request->user;
        $dish->image = $image_store;
        $dish->save();
        return redirect("dish/$dish->id");

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    //  This shows the details of a dish based on its id
    public function show($id)
    {
        $dish = Dish::find($id);
        $userid = $dish->user_id;

        $restaurant = User::find($userid);

        // storing the dish id into the session 'userid'
        $value = session('purchasedish');
        $value = session('purchasedish', 'default');
        session(['purchasedish' => $dish]);

        return view('dishes.show')->with('dish', $dish)->with('restaurant', $restaurant);
        

    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    //This is the form which allow user to update a dish in a database
    public function edit($id)
    {
        $dish = Dish::find($id);
        return view('dishes.edit_form')->with('dish', $dish)->with('users', User::all());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

     //update form are passed on to here
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required|max:255',
            'price' => 'required|numeric|min:0.5|max:1000'
        ]);

        $dish =  Dish::find($id);
        $dish->name = $request->name;
        $dish->price = $request->price;
        $dish->save();
        return redirect("dish/$dish->id");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    //  This deletes the dish
    public function destroy($id)
    {
        $dish=Dish::find($id);
        $dish->delete();
        return redirect("dish");
    }
}
