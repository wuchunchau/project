<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    protected $fillable = ['user_name', 'user_id', 'dish_id', 'quantity'];

    function dish(){
        return $this->belongsTo('App\Dish');
    }
    function user(){
        return $this->belongsTo('App\user');
    }
}
