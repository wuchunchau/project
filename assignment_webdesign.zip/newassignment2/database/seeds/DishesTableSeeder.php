<?php

use Illuminate\Database\Seeder;

class DishesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
            
        DB::table('dishes')->insert([
            'name' => 'Apple Pie',
            'price' => '6.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 5,

        ]);

        DB::table('dishes')->insert([
            'name' => 'Special fried rice',
            'price' => '11.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 6,

        ]);

        DB::table('dishes')->insert([
            'name' => 'Super seafood combination',
            'price' => '999.99',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 6,

        ]);

        DB::table('dishes')->insert([
            'name' => 'Fried chickens',
            'price' => '15.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 4,

        ]);

        DB::table('dishes')->insert([
            'name' => 'giant sushi',
            'price' => '55.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);

        DB::table('dishes')->insert([
            'name' => 'small ramen',
            'price' => '8.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);

        DB::table('dishes')->insert([
            'name' => 'medium ramen',
            'price' => '11.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);

        DB::table('dishes')->insert([
            'name' => 'large ramen',
            'price' => '13.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,
            'image' => 'dishes_images/default.png',

        ]);

        DB::table('dishes')->insert([
            'name' => 'karrage chicken',
            'price' => '12.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);

        DB::table('dishes')->insert([
            'name' => 'teriyaki chicken',
            'price' => '12.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);

        DB::table('dishes')->insert([
            'name' => 'salmon sushi',
            'price' => '6',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);

        DB::table('dishes')->insert([
            'name' => 'Large Sashimi set',
            'price' => '66.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);

        DB::table('dishes')->insert([
            'name' => 'Salmon Sashimi set',
            'price' => '42.00',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
            'user_id' => 7,

        ]);
    }
}
