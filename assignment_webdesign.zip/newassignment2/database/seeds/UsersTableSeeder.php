<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'Bob',
            'email' => 'Bob@gmail.com',
            'password' => bcrypt('123456'),
            'address' => '123 abc street, YYY',
            'usertype' => 'consumer'
        ]);

        DB::table('users')->insert([
            'name' => 'Fred',
            'email' => 'Fred@gmail.com',
            'password' => bcrypt('123456'),
            'address' => '11 Davrod street, Robertson',
            'usertype' => 'consumer'

        ]);


        DB::table('users')->insert([
            'name' => 'Tony',
            'email' => 'Tony@gmail.com',
            'password' => bcrypt('654321'),
            'address' => '88 kennen road, Sunnybank hill',
            'usertype' => 'consumer'
        ]);

        DB::table('users')->insert([
            'name' => '88topaki',
            'email' => '88topaki@hotmail.com',
            'password' => bcrypt('888888'),
            'address' => '88 pineland road, Sunnybank hill',
            'usertype' => 'restaurant'
        ]);

        DB::table('users')->insert([
            'name' => 'Beststeakhouse',
            'email' => 'Beststeak@hotmail.com',
            'password' => bcrypt('666666'),
            'address' => '171 mains road, Sunnybank',
            'usertype' => 'restaurant'
        ]);

        DB::table('users')->insert([
            'name' => 'SunnybankOriental',
            'email' => 'SBOriental@hotmail.com',
            'password' => bcrypt('112233445566'),
            'address' => '56 mains road, Sunnybank',
            'usertype' => 'restaurant'
        ]);


        DB::table('users')->insert([
            'name' => 'SushiEdo',
            'email' => 'sushiedo@gmail.com',
            'password' => bcrypt('123456'),
            'address' => '111 mains road, Sunnybank',
            'usertype' => 'restaurant'
        ]);
    }
}
