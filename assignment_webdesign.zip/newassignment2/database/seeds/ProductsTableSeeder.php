<?php

use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
        {
            DB::table('products')->insert([
                'name' => 'Apple iPhone 6',
                'price' => '567',
                'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
                'manufacturer_id' => 1,
    
            ]);
    
            DB::table('products')->insert([
                'name' => 'Samsung Note 4',
                'price' => '600',
                'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
                'manufacturer_id' => 2,
    
            ]);
    
            DB::table('products')->insert([
                'name' => 'Nokia 8810',
                'price' => '432',
                'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
                'manufacturer_id' => 3,
    
            ]);
        
        }
}
