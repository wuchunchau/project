<?php

use Illuminate\Database\Seeder;

class PurchasesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('purchases')->insert([
            'user_name' => 'Bob',
            'user_id' => 1,
            'dish_id' => 2,
            'quantity' => 4,
            'created_at' => DB::raw('CURRENT_TIMESTAMP'),
            'updated_at' => DB::raw('CURRENT_TIMESTAMP')

        ]);

        DB::table('purchases')->insert([
            'user_name' => 'Bob',
            'user_id' => 1,
            'dish_id' => 4,
            'quantity' => 7,
            'created_at' => DB::raw('CURRENT_TIMESTAMP'),
            'updated_at' => DB::raw('CURRENT_TIMESTAMP')

        ]);

        DB::table('purchases')->insert([
            'user_name' => 'Bob',
            'user_id' => 1,
            'dish_id' => 3,
            'quantity' => 2,
            'created_at' => DB::raw('CURRENT_TIMESTAMP'),
            'updated_at' => DB::raw('CURRENT_TIMESTAMP')

        ]);

        DB::table('purchases')->insert([
            'user_name' => 'Tony',
            'user_id' => 3,
            'dish_id' => 6,
            'quantity' => 1,
            'created_at' => DB::raw('CURRENT_TIMESTAMP'),
            'updated_at' => DB::raw('CURRENT_TIMESTAMP')

        ]);
    }
}
