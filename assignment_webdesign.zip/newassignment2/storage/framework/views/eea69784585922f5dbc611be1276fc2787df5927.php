
<?php $__env->startSection('title'); ?>
    Dishes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Peer_review</h1>
<!-- relative path -->
<img src= "<?php echo e(asset("photos/peer_review.jpg")); ?>" alt= "peer_review">



<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/newassignment2/resources/views/extra/peer_review.blade.php ENDPATH**/ ?>