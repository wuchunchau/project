
<?php $__env->startSection('title'); ?>
    Dishes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2>Thank you for ordering! Your order were successful!<h2>
    <br>
    <h3><?php echo e($dish->name); ?></h3>
    <p>Price: <?php echo e($dish->price); ?></p>
    <p>Quantity: <?php echo e($purchase->quantity); ?></p>
    <br>
    <h3>Consumers details:</h3>
    <p>Consumer name: <?php echo e($user->name); ?> </p>
    <h5>Delivers to:</h5>
    <p><?php echo e($user->address); ?> </p>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/finalassignment2/resources/views/purchases/show_form.blade.php ENDPATH**/ ?>