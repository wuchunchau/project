
<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1><?php echo e($product->name); ?></h1>
    <p><?php echo e($product->price); ?></p>
    <p><?php echo e($product->manufacturer->name); ?></p>
    <?php if(Auth::check()): ?>
        <p><a href='<?php echo e(url("product/$product->id/edit")); ?>'>Edit</a></p>
    
    <?php endif; ?>

    <p>
        <form method="POST" action='<?php echo e(url("product/$product->id")); ?>'>
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

            <input type="submit" value="Delete">
        </form>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/prod/resources/views/products/show.blade.php ENDPATH**/ ?>