
<?php $__env->startSection('title'); ?>
    Dishes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Er Diagram</h1>
<!-- relative path -->
<img src= "<?php echo e(asset("photos/ERD2.JPG")); ?>" alt="erdiagram">



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/newassignment2/resources/views/extra/er_diagram.blade.php ENDPATH**/ ?>