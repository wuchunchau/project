

<?php $__env->startSection('title'); ?>
  Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="post" action=' <?php echo e(url("product/$product->id")); ?>'>
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <p><label>Name </label>
    <input type="text" name="name" value= "<?php echo e($product->name); ?>">
  </p>
  <p>
    <label>Price</label>
    <input type="text" name="price" value= "<?php echo e($product->price); ?>"> <br></p>
  </p><select name = "manufacturer">
  <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($manufacturer->id == $product->manufacturer_id): ?>
        <option value="<?php echo e($manufacturer->id); ?>" selected="selected"><?php echo e($manufacturer->name); ?></option>
    <?php else: ?>
        <option value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->name); ?></option>
    <?php endif; ?> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <input type="submit" value="Update">
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week8/prod/resources/views/products/edit_form.blade.php ENDPATH**/ ?>