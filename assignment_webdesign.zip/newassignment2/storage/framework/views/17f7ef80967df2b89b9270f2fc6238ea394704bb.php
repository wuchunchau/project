
<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  <form method="POST" action='<?php echo e(url("product")); ?>'>
    <?php echo e(csrf_field()); ?>

    <p>
      <label>Name: </label>
      <input type="text" name="name">
    </p>
    <p>
      <label>Price: </label>
      <input type="text" name="price">
    </p>
    <p>
        <select name="manufacturer">
    <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select></p>
    <input type="submit" value="Create"> 
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week8/prod/resources/views/products/create_form.blade.php ENDPATH**/ ?>