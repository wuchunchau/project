
<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="product/<?php echo e($product->id); ?>"><li><?php echo e($product->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
    <a href='<?php echo e(url("product/create")); ?>'>Create</a></p>
    <p>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/finalassignment2/resources/views/products/index.blade.php ENDPATH**/ ?>