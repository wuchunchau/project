
<?php $__env->startSection('title'); ?>
    Purchase
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




  <form method="POST" action='<?php echo e(url("purchase")); ?>'>
    <?php echo e(csrf_field()); ?>

    You are ordering <?php echo e($dish->name); ?>


    <br>
    
      <input name = "quantity" type="number" min="1" max="100">


      <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">

      <input type="hidden" name="user_name" value="<?php echo e(Auth::user()->name); ?>">


      <input type="hidden" name="dish_id" value= "<?php echo e($dish->id); ?>">

    <br>
    <br>
      <input type="submit" value="Place order"> 
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/finalassignment2/resources/views/purchases/create_form.blade.php ENDPATH**/ ?>