<!DOCTYPE html>
<html>
<head>
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/wp.css')); ?>">
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <p><a href='<?php echo e(url("product/")); ?>'>Home</a></p>
</body>
</html><?php /**PATH /var/www/html/webAppDev/week8/prod/resources/views/layouts/master.blade.php ENDPATH**/ ?>