
<?php $__env->startSection('title'); ?>
    Dishes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/wp.css')); ?>">
    <h2>Thank you for ordering! Your order were successful!<h2>
    <br>
    <h3><?php echo e($dish->name); ?></h3>
    <p>Price per item: <strong><?php echo e($dish->price); ?></strong></p>
    <p>Quantity: <strong><?php echo e($purchase->quantity); ?></strong></p>
    <br>
    <h3>Consumers details:</h3>
    <p>Consumer name: <strong><?php echo e($user->name); ?> </strong></p>
    <p>Delivers to:<strong><?php echo e($user->address); ?> </strong></p>
    




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/newassignment2/resources/views/purchases/show_form.blade.php ENDPATH**/ ?>