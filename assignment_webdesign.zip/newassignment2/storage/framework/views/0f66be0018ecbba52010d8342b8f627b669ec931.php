
<?php $__env->startSection('title'); ?>
    Dishes
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




  <form method="POST" action='<?php echo e(url("dish")); ?>'>
    <?php echo e(csrf_field()); ?>

    <?php if(count($errors->get('name')) > 0): ?>
      <p><label>Name </label>
      <input type="text" name="name" value= "<?php echo e(old('name')); ?>">
        <div class="alert">

            <?php echo e($errors->first('name')); ?>


        </div>
    </p>
    <?php else: ?>

      <p><label>Name </label>
      <input type="text" name="name" value= "<?php echo e(old('name')); ?>" >

        
   </p>
    <?php endif; ?>


    <?php if(count($errors->get('price')) > 0): ?>
      <p><label>Price </label>
      <input type="text" name="price" value= "<?php echo e(old('price')); ?>">
        <div class="alert">
  
            <?php echo e($errors->first('price')); ?>

          
        </div>
    <?php else: ?>
      <p><label>Price </label>
      <input type="text" name="price" value= "<?php echo e(old('price')); ?>">
      </p>
    <?php endif; ?>
    

      <input type="hidden" name="user" value= "<?php echo e(Auth::id()); ?>">
      </p>
      <input type="submit" value="Create"> 
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/finalassignment2/resources/views/dishes/create_form.blade.php ENDPATH**/ ?>