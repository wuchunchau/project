
<?php $__env->startSection('title'); ?>
    Dishes
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




  <form method="POST" action='<?php echo e(url("dish")); ?>'enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php if(count($errors->get('name')) > 0): ?>
      <p><label>Name </label>
      <input type="text" name="name" value= "<?php echo e(old('name')); ?>">
        <div class="alert">

            <?php echo e($errors->first('name')); ?>


        </div>
    </p>
    <?php else: ?>

      <p><label>Name </label>
      <input type="text" name="name" value= "<?php echo e(old('name')); ?>" >

        
   </p>
    <?php endif; ?>


    <?php if(count($errors->get('price')) > 0): ?>
      <p><label>Price </label>
      <input type="text" name="price" value= "<?php echo e(old('price')); ?>">
        <div class="alert">
  
            <?php echo e($errors->first('price')); ?>

          
        </div>
    <?php else: ?>
      <p><label>Price </label>
      <input type="text" name="price" value= "<?php echo e(old('price')); ?>">
      </p>
    <?php endif; ?>

    <?php if(count($errors->get('image')) > 0): ?>
      <p><input type="file" name="image"> </p>
      <p>Upload image for your dish!!</p>
      <div class="alert">
  
       <?php echo e($errors->first('image')); ?>


      </div>
    <?php else: ?>
      <p><input type="file" name="image"> </p>
      <p>Upload image for your dish!!</p>
    <?php endif; ?>

      <input type="hidden" name="user" value= "<?php echo e(Auth::id()); ?>">

      <input type="submit" value="Create"> 
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/newassignment2/resources/views/dishes/create_form.blade.php ENDPATH**/ ?>