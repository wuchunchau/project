

<?php $__env->startSection('title'); ?>

    Dishes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/wp.css')); ?>">


    <h1><?php echo e($dish->name); ?></h1>

    <?php if($dish->image): ?>
        <img src="<?php echo e(url($dish->image)); ?>" alt="dish image" style="width:300px;height:300px;">
    <?php else: ?>
        <p>There are no photo avaiable for this dish!</P>
    <?php endif; ?>

    <p>Price: <?php echo e($dish->price); ?></p>

    <?php if(Auth::check()): ?>
        <?php if(Auth::user()->usertype == 'consumer'): ?>

            <h4><a href='<?php echo e(url("purchase/create")); ?>'>Purchase dish</a></h4>

        <?php endif; ?>
    <?php endif; ?>
    <br>
    <br>

    <h3><a href="<?php echo e(url ("restaurant/$restaurant->id")); ?>">Find more dishes from <?php echo e($restaurant->name); ?>!!</a></h3>
 
    <?php if(Auth::check()): ?>
        <?php if(Auth::user()->name == $restaurant->name): ?>
        <h4><a href='<?php echo e(url("dish/$dish->id/edit")); ?>'>update dish</a></h4>
        
        <h5>
            <form method="POST" action='<?php echo e(url("dish/$dish->id")); ?>'>
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Delete">
            </form>
        </h5>   
        <?php endif; ?>
    
    <?php endif; ?>



    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/newassignment2/resources/views/dishes/show.blade.php ENDPATH**/ ?>