

<?php $__env->startSection('title'); ?>
  Dishes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<form method="post" action=' <?php echo e(url("dish/$dish->id")); ?>'>
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>


    <?php if(count($errors->get('name')) > 0): ?>
    <p><label>Name </label>
    <input type="text" name="name" value= "<?php echo e(old('$dish->name')); ?>">
      <div class="alert">
    
          <?php echo e($errors->first('name')); ?>

        
      </div>
    <?php else: ?>     
    <p><label>Name </label>
    <input type="text" name="name" value= "<?php echo e($dish->name); ?>"readonly>
    <?php endif; ?>
   </p>


  <p>

    <?php if(count($errors->get('price')) > 0): ?>
    <label>Price</label>
    <input type="text" name="price" value= "<?php echo e(old('$dish->price')); ?>"> 
      <div class="alert">
        
          <?php echo e($errors->first('price')); ?>

        
      </div>
    <?php else: ?>
    <label>Price</label>
    <input type="text" name="price" value= "<?php echo e($dish->price); ?>"> 
    <?php endif; ?>
  </p>
  




  <input type="submit" value="Update">
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/finalassignment2/resources/views/dishes/edit_form.blade.php ENDPATH**/ ?>