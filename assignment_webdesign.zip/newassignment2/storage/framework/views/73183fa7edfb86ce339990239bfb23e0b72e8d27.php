
<?php $__env->startSection('title'); ?>
    Dishes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Documentation</h1>
<!-- relative path -->
<img src= "<?php echo e(asset("photos/documentation.jpg")); ?>" alt= "documentation">



<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/newassignment2/resources/views/extra/documentation.blade.php ENDPATH**/ ?>