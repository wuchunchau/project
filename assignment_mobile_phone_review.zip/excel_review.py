import sqlite3
connection = sqlite3.connect("AssignmentDB.db")
cursor = connection.cursor()


def year_reviews():
    # Joining two table and selecting the title, brand and date using group by date
    cursor.execute("""SELECT i.title, i.brand, r.date 
                        FROM items as i, reviews as r 
                        WHERE i.asin = r.asin 
                        GROUP BY r.date;""")
    result = cursor.fetchall()
    count = 0
    # Only extracting the year out and putting all of them into a new list along with other attributes
    list1 = []
    for i in result:
        date = i[2]
        year = date[-4:]
        new_tuple = (i[0], i[1], year)
        list1.append(new_tuple)

    list1.sort()

    # creating and inserting list1 into a new table
    cursor.execute("DROP TABLE IF EXISTS product_years;")
    cursor.execute("""Create table product_years(
                    title VARCHAR(200),
                    brand VARCHAR(20),
                    year int);""")

    cursor.executemany("insert into product_years VALUES(?, ?, ?);", list1)
    connection.commit()

    # Selecting title, brand, number of review between 2000 - 2020 group by the title and year
    cursor.execute("""SELECT title, brand, COUNT(year) as total_review, year FROM product_years
                             WHERE year between 2000 AND 2020
                             GROUP BY title, year;""")


    yearreviews = cursor.fetchall()

    return yearreviews



def Write_into_excel(yearreviews):
    # Creating new excel file and writing the data in
    import xlsxwriter
    workbook = xlsxwriter.Workbook('comparison.xlsx')
    worksheet = workbook.add_worksheet("reviews per year")

    # writing first row
    first_row = ("Title", "Brand", "Number of reviews", "Year")
    for col_num, data in enumerate(first_row):
        worksheet.write(0, col_num, data)

    # writing in the data
    for row_num, row_data in enumerate(yearreviews):
        for col_num, col_data in enumerate(row_data):
            if row_num == 0:
                pass
            else:
                worksheet.write(row_num, col_num, col_data)

    return workbook



Write_into_excel(year_reviews())



def verified_customer(workbook):
    connection = sqlite3.connect("AssignmentDB.db")
    cursor = connection.cursor()

    # Selecting the TRUE verified GROUP BY brand
    cursor.execute("""SELECT i.brand, CAST(COUNT(r.verified) AS float)
                    FROM items as i, reviews as r
                    WHERE i.asin = r.asin AND r.verified = 1
                    GROUP BY i.brand
                    ORDER BY i.brand""")

    true_verified = cursor.fetchall()

    # Selecting ALL verified GROUP BY brand
    cursor.execute("""SELECT i.brand, CAST(COUNT(r.verified) AS float)
                FROM items as i, reviews as r
                WHERE i.asin = r.asin
                GROUP BY i.brand
                ORDER BY i.brand""")

    all_verified = cursor.fetchall()



# don't know how to find the value of amazon or kindle.....hoping this can give me some marks
# import csv
# with open('reviews.csv') as csv_file:
#     wb = csv.reader(csv_file)
#     for row in wb:
#         print(row[1])




# Caculating percentage by looping two table
    customer_and_percentage = []
    for true, all in zip(true_verified, all_verified):
        percentage = float(true[1])/float(all[1])*100
        T1 = (true[0], percentage)
        T2 = tuple(T1)
        customer_and_percentage.append(T2)


    worksheet = workbook.add_worksheet("customers")

    # writing first row
    first_row = ("brand", "percentage of verified customers")
    for col_num, data in enumerate(first_row):
        worksheet.write(0, col_num, data)

    # writing in the data
    for row_num, row_data in enumerate(customer_and_percentage):
        for col_num, col_data in enumerate(row_data):
            if row_num == 0:
                pass
            else:
                worksheet.write(row_num, col_num, col_data)
    workbook.close()



verified_customer(Write_into_excel(year_reviews()))



connection.close()






