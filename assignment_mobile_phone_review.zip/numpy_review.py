import openpyxl
import sqlite3
import matplotlib.pyplot as plt
connection = sqlite3.connect("AssignmentDB.db")
cursor = connection.cursor()


# Please see readme.txt for why I am creating a new table and using a new excel file

def create_review_new():
    # CREATE THE reviews_new Table

    cursor.execute("DROP TABLE IF EXISTS reviews_new;")
    cursor.execute ("""CREATE TABLE reviews_new(
                    asin VARCHAR(20),
                    name VARCHAR(30),
                    rating INTEGER,
                    date DATE,
                    verified VARCHAR(10),
                    title VARCHAR(100),
                    body VARCHAR(50),
                    helpfulVotes INTEGER,
                    FOREIGN KEY(asin) REFERENCES items(asin));""")



    wb = openpyxl.load_workbook("reviews_new.xlsx")
    reviews = wb['20190928-reviews']

    reviews_cells = []

    #iterate each shell and put each row in tuple
    for i, rows in enumerate(reviews.iter_rows()):
        row_cells = []
        if i == 0:
            continue
        for cell in rows:
            row_cells.append(cell.value)
        reviews_cells.append(tuple(row_cells))
    # insert into reviews_new Table
    cursor.executemany('INSERT INTO reviews_new VALUES(?,?,?,?,?,?,?,?);', reviews_cells)


    connection.commit()



create_review_new()



def top3_review_plot():
    # Finding the top 3 brand with the most review
    cursor.execute("""SELECT i.brand, COUNT(r.verified) as total_review
                        FROM items as i, reviews as r
                        WHERE i.asin = r.asin GROUP BY i.brand
                        ORDER BY total_review desc
                        LIMIT 3
                        ;""")

    result = cursor.fetchall()

    print(result)
    print("\n")

    # We now know the top 3 are Samsung, Apple and Motorola, Find the number of review per month for them.
    cursor.execute("""SELECT i.brand, COUNT(r.verified), strftime("%m", r.date)
                        FROM items as i, reviews_new as r
                        WHERE i.asin = r.asin AND (i.brand = 'Samsung' OR i.brand = 'Apple' OR i.brand = 'Motorola')
                        GROUP BY i.brand, strftime("%m", r.date)
                        ORDER BY i.brand;""")

    result1 = cursor.fetchall()

    # Put the results in the corresponding brand's list
    apple_review = []
    samsung_review = []
    motorola_review = []
    apple_date = []
    samsung_date = []
    motorola_date = []

    for i in result1:
        if i[0] == "Apple":
            apple_review.append(i[1])
            apple_date.append(i[2])
        elif i[0] == "Samsung":
            samsung_review.append(i[1])
            samsung_date.append(i[2])
        elif i[0] == "Motorola":
            motorola_review.append(i[1])
            motorola_date.append(i[2])

    # plot the result
    plt.figure(1)
    plt.plot(apple_date, apple_review, Label="Apple")
    plt.plot(samsung_date, samsung_review, Label="Samsung")
    plt.plot(motorola_date, motorola_review, Label="Motorola")

    plt.xlabel("Months")
    plt.ylabel("Reviews")
    plt.title("Total of reviews per month for the top three brand")
    plt.legend()
    plt.show()



top3_review_plot()



def average_rating_plot():
    # electing brand, average rating and date for results between 2017-2019
    cursor.execute("""SELECT i.brand, AVG(i.rating), strftime("%m", r.date)
                    FROM items as i, reviews_new as r
                    WHERE i.asin = r.asin AND (r.date BETWEEN Date('2017-01-01') AND Date('2019-12-31'))
                    GROUP BY i.brand, strftime("%m", r.date)
                    """)


    average_month = cursor.fetchall()


    # Creating temp_data table to store the result
    cursor.execute("DROP TABLE IF EXISTS temp_data;")

    cursor.execute("""  CREATE TABLE temp_data(
                        brand VARCHAR(20),
                        rating_month FLOAT,
                        date DATE)""")

    cursor.executemany("INSERT INTO temp_data VALUES(?,?,?);", average_month)

    connection.commit()

    # Finding the Distinct brand, average rating_month of the top 5 brand
    cursor.execute("""SELECT brand, AVG(rating_month) as average
                        FROM temp_data
                        GROUP BY brand
                        ORDER BY average desc
                        LIMIT 5;""")

    top5 = cursor.fetchall()
    print(top5)
    cursor.execute("DROP TABLE IF EXISTS temp_data;")


    # We now know the top five brand are Xiaomi, Huawei, OnePlus, ASUS and Motorola
    # Put the average_month result into list
    Xiaomi_rating = []
    Huawei_rating = []
    OnePlus_rating = []
    ASUS_rating = []
    Motorola_rating = []

    Xiaomi_date = []
    Huawei_date = []
    OnePlus_date = []
    ASUS_date = []
    Motorola_date = []

    for i in average_month:
        if i[0] == "Xiaomi":
            Xiaomi_rating.append(i[1])
            Xiaomi_date.append(i[2])
        elif i[0] == "HUAWEI":
            Huawei_rating.append(i[1])
            Huawei_date.append(i[2])
        elif i[0] == "OnePlus":
            OnePlus_rating.append(i[1])
            OnePlus_date.append(i[2])
        elif i[0] == "ASUS":
            ASUS_rating.append(i[1])
            ASUS_date.append(i[2])
        elif i[0] == "Motorola":
            Motorola_rating.append(i[1])
            Motorola_date.append(i[2])


    # plot the results
    plt.figure(2)
    plt.plot(Xiaomi_date, Xiaomi_rating, Label="Xiaomi")
    plt.plot(Huawei_date, Huawei_rating, Label="Huawei")
    plt.plot(OnePlus_date, OnePlus_rating, Label="OnePlus")
    plt.plot(ASUS_date, ASUS_rating, Label="ASUS")
    plt.plot(Motorola_date, Motorola_rating, Label="Motorola")

    plt.xlabel("Month")
    plt.ylabel("Average rating")
    plt.title("Average rating per month for the top five brand during 2017 and 2019")
    plt.legend()
    plt.show()



average_rating_plot()



def review_against_rating():
    # Find average rating and total reviews of each items
    cursor.execute("""SELECT AVG(rating), totalReviews
                        FROM items
                        GROUP BY title""")

    rating_review = cursor.fetchall()

    # put the results in corresponding list
    average_ratings = []
    total_reviews = []

    for i in rating_review:
        average_ratings.append(i[0])
        total_reviews.append(i[1])

    # plot the results
    plt.figure(3)
    plt.plot(average_ratings, total_reviews, 'ro')
    plt.xlabel("Average rating")
    plt.ylabel("Total reviews")
    plt.title("Number of reviews against Average rating for each product")
    plt.show()



review_against_rating()


connection.close()