import sqlite3
connection = sqlite3.connect("AssignmentDB.db")
cursor = connection.cursor()


def Select_Distinct():
    # Selecting the distinctive product titles that have had at least 1 review in 2019
    cursor.execute("""SELECT i.title, i.brand, i.rating, i.totalReviews
                        FROM items as i, reviews as r 
                        WHERE i.asin = r.asin  AND r.date LIKE "%2019%"
                        GROUP BY i.title
                        order by i.title; """)
    result = cursor.fetchall()

    # making sure the title is distinctive
    distinct_result = []
    for i in result:
        if i[0] in distinct_result:
            pass
        else:
            distinct_result.append(i)
    return distinct_result


print(Select_Distinct())
print("\n")


def Create_reviewsummaries_insert(distinct_result):
    # Creating the new table and insert distinct_result into it
    connection = sqlite3.connect("AssignmentDB.db")
    cursor = connection.cursor()

    # create the review_summaries TABLE
    cursor.execute("DROP TABLE IF EXISTS review_summaries;")
    sql_command ="""CREATE TABLE review_summaries (
                title VARCHAR(100),
                brand text,
                rating FLOAT,
                totalReview INTEGER);"""

    cursor.execute(sql_command)

    # insert into review_summaries table
    cursor.executemany('INSERT INTO review_summaries VALUES(?,?,?,?);', distinct_result)
    connection.commit()



Create_reviewsummaries_insert(Select_Distinct())



def averagerating_product():
    #Select average rating for each product title that has at least 1 review in 2019
    connection = sqlite3.connect("AssignmentDB.db")
    cursor = connection.cursor()
    cursor.execute("""SELECT i.title, AVG(i.rating) as Average_rating 
                        FROM items as i, review_summaries as rs
                        WHERE i.title = rs.title
                        GROUP BY i.title
                        ORDER BY Average_rating desc; """)
    result = cursor.fetchall()

    for i in result:
        print("Title : ", i[0])
        print("Average rating : ", i[1])





averagerating_product()

connection.close()