import sqlite3
connection = sqlite3.connect("AssignmentDB.db")
cursor = connection.cursor()


def CreateItemTable():
# create the items TABLE
    cursor.execute("DROP TABLE IF EXISTS items;")
    sql_command ="""CREATE TABLE items (
                    asin VARCHAR(20) PRIMARY KEY,
                    brand text,
                    title VARCHAR(100),
                    url VARCHAR(100),
                    image VARCHAR(100),
                    rating FLOAT,
                    reviewUrl VARCHAR(100),
                    totalReviews INTEGER,
                    prices DOUBLE);"""

    cursor.execute(sql_command)

def CreateReviewsTable():
# CREATE THE reviews Table
    cursor.execute("DROP TABLE IF EXISTS reviews;")
    sql_command = """CREATE TABLE reviews(
                    asin VARCHAR(20),
                    name VARCHAR(30),
                    rating INTEGER,
                    date DATE,
                    verified VARCHAR(10),
                    title VARCHAR(100),
                    body VARCHAR(50),
                    helpfulVotes INTEGER,
                    FOREIGN KEY(asin) REFERENCES items(asin));"""

    cursor.execute(sql_command)


CreateItemTable()
CreateReviewsTable()

connection.close()