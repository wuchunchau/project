import sqlite3
connection = sqlite3.connect("AssignmentDB.db")
cursor = connection.cursor()


def highend_product():
    # Select product which have priced over $800
    cursor.execute("""SELECT DISTINCT asin, title, prices
                        FROM items
                        WHERE prices != "None" AND prices >= 800.00 """)

    result = cursor.fetchall()

    list1 = []
    empty = ""
    # Selecting second amount for mulitiple price, putting them in str and removing ",", put them back into a tuple and append to list1
    for i in result:
        string_price = str(i[2])
        reversed_string_price = string_price[::-1]
        for number in reversed_string_price:
            if number == "$":
                break
            else:
                empty = empty + number
        price = empty[::-1]
        price = price.replace(",", "")
        empty = ""
        T1 = (i[0], i[1], price)
        T1 = tuple(T1)
        list1.append(T1)

    # only append the tuple into list2 if the price is over or equal 800
    list2 = []
    for i in list1:
        price = float(i[2])
        if price >= 800.00:
            list2.append(i)

    # Creating high_end_products table and putting the results into the table
    cursor.execute("DROP TABLE IF EXISTS high_end_products;")

    cursor.execute("""  CREATE TABLE high_end_products(
                        asin VARCHAR(100),
                        title VARCHAR(100),
                        price DOUBLE)""")

    cursor.executemany("INSERT INTO high_end_products VALUES(?,?,?);", list2)

    connection.commit()



highend_product()



def top10_words():
    # Selecting review's title and body of the high end products
    cursor.execute("""SELECT r.title, r.body
                        FROM reviews as r, high_end_products as h
                        WHERE r.asin = h.asin""")

    result2 = cursor.fetchall()

    import re

    totalstring = ""

    # Filtering all the non-alpha characters of both title and body, combine both string into totalstring
    for i in result2:
        string1 = str(i[0])
        string2 = str(i[1])
        cleanString = re.sub('[^A-Za-z]+', " ", string1)
        cleanString2 = re.sub('[^A-Za-z]+', " ", string2)
        totalstring = totalstring.__add__(cleanString + cleanString2)

    # spliting the whole string into crazylist, the list will contains list of all the words
    crazylist = totalstring.split()

    # putting the words into dict1, ignoring words that has 4 words or less because it can be meaningless word such as is, a, are.
    dict1 = {}
    for word in crazylist:
        if len(word) <= 4:
            pass
        # if the key is replied, the value will +1
        elif dict1.__contains__(word):
           dict1[word] += 1
        else:
           dict1[word] = 1

    # sorting the dictionary by value in descending order
    dict1 = {k: v for k, v in sorted(dict1.items(), key=lambda item: item[1], reverse=True)}

    # only displaying the top 10 result
    count = 0
    for key in dict1:
        if count != 10:
            print("Word:", key, "\n", "frequency:", dict1[key], "\n")
            count += 1



top10_words()


connection.close()



