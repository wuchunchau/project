***Assignment were done using Pycharm***

---All the python document---
created_review.py 	- create database
insert.py 		- insert items and reviews into database
sql_review.py 		- Task2
excel_review.py 	- Task3
numpy_review.py 	- Task4
7810ICT student.py	 - requirement for 7810ICT student


----Task didn't completed---
Task4 - question 4
Task3 - question 2 (using CSV for Amazon, Kindle) please find excel_reivew.py line 97 - line 102


---About review_new.xlsx---
Please read the word document review_new_explanation