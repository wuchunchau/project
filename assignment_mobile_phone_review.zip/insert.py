import sqlite3
import openpyxl
connection = sqlite3.connect("AssignmentDB.db")
cursor = connection.cursor()


def extract_excel_insert():
    wb = openpyxl.load_workbook("items.xlsx")
    items = wb['20190928-items']
    items_cells = []
    #iterate each shell and put each row in the list as tuple (skipping first row)
    for i, rows in enumerate(items.iter_rows()):
        row_cells = []
        if i == 0:
            continue
        for cell in rows:
            row_cells.append(cell.value)
        items_cells.append(tuple(row_cells))

    # insert into items table
    cursor.executemany('INSERT INTO items VALUES(?,?,?,?,?,?,?,?,?);', items_cells)

    connection.commit()



extract_excel_insert()



def extract_excel_insert2():
    wb = openpyxl.load_workbook("reviews.xlsx")
    reviews = wb['20190928-reviews']
    reviews_cells = []
    #iterate each shell and put each row in tuple
    for i, rows in enumerate(reviews.iter_rows()):
        row_cells = []
        if i == 0:
            continue
        for cell in rows:
            row_cells.append(cell.value)
        reviews_cells.append(tuple(row_cells))
    # insert into reviews Table
    cursor.executemany('INSERT INTO reviews VALUES(?,?,?,?,?,?,?,?);', reviews_cells)


    connection.commit()



extract_excel_insert2()

connection.close()


